//
//  FeatureMenuTabBar.h
//  FeatureMenuTabBar
//
//  Created by Sandi Permata on 18.12.19.
//  Copyright © 2019 everest. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FeatureMenuTabBar.
FOUNDATION_EXPORT double FeatureMenuTabBarVersionNumber;

//! Project version string for FeatureMenuTabBar.
FOUNDATION_EXPORT const unsigned char FeatureMenuTabBarVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FeatureMenuTabBar/PublicHeader.h>


