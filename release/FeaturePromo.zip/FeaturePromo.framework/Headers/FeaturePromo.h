//
//  FeaturePromo.h
//  FeaturePromo
//
//  Created by Sandi Permata on 18.12.19.
//  Copyright © 2019 everest. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FeaturePromo.
FOUNDATION_EXPORT double FeaturePromoVersionNumber;

//! Project version string for FeaturePromo.
FOUNDATION_EXPORT const unsigned char FeaturePromoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FeaturePromo/PublicHeader.h>


