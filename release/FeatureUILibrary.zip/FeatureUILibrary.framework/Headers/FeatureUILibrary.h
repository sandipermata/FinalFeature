//
//  FeatureUILibrary.h
//  FeatureUILibrary
//
//  Created by Sandi Permata on 20.12.19.
//  Copyright © 2019 mvvm. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FeatureUILibrary.
FOUNDATION_EXPORT double FeatureUILibraryVersionNumber;

//! Project version string for FeatureUILibrary.
FOUNDATION_EXPORT const unsigned char FeatureUILibraryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FeatureUILibrary/PublicHeader.h>


